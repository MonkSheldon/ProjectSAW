<?php

function CheckSession()
{
	session_start();
	if(!isset($_SESSION['login'])){
			header('Location: login.php');
			exit();
	}
//manca la funzione sessione per il carrello


	
}
?>