<?php include('header.html'); 
$C=true;
myheader($C);
?>

	<div class="container-fluid" style="width: 100%; height:35%;" >
		<div class="row">
		<div id="carouselExampleIndicators" class="carousel slide" data-ride="carousel">
		  <ol class="carousel-indicators">
			<li data-target="#carouselExampleIndicators" data-slide-to="0" class="active"></li>
			<li data-target="#carouselExampleIndicators" data-slide-to="1"></li>
			<li data-target="#carouselExampleIndicators" data-slide-to="2"></li>
			<li data-target="#carouselExampleIndicators" data-slide-to="3"></li>
			<li data-target="#carouselExampleIndicators" data-slide-to="4"></li>
			<li data-target="#carouselExampleIndicators" data-slide-to="5"></li>
		  </ol>
		  <div class="carousel">
			<div class="carousel-item active show-for-large-up" >
			 <img class="d-block " src="moto.jpg" style="width: 100%" alt="">
			</div>
			<div class="carousel-item " >
			  <img class="d-block " src="nave.jpg" style="width: 100%" alt="">
			</div>
			<div class="carousel-item" >
			  <img class="d-block " src="car.jpg" style="width: 100%" alt="">
			</div>
			<div class="carousel-item " >
			  <img class="d-block " src="aereo.jpg" style="width: 100%" alt="">
			</div>
			<div class="carousel-item" >
			  <img class="d-block " src="treno.jpg" style="width: 100%" alt="">
			</div>
			<div class="carousel-item " >
			  <img class="d-block " src="bici.jpg" style="width: 100%" alt="">
			</div>
		  </div>
		  <a class="carousel-control-prev" href="#carouselExampleIndicators" role="button" data-slide="prev">
			<span class="carousel-control-prev-icon" aria-hidden="true"></span>
			<span class="sr-only">Previous</span>
		  </a>
		  <a class="carousel-control-next" href="#carouselExampleIndicators" role="button" data-slide="next">
			<span class="carousel-control-next-icon" aria-hidden="true"></span>
			<span class="sr-only">Next</span>
		  </a>
		</div>
		</div>
</div>
<br><h2>Veicoli</h2><br>

<div class="card-columns">
	<div class="card" style="width: 18rem">
		<img class="card-img-top" src="aereomini.jpg" alt="Card image cap">
			<div class="card-body">
				<h5 class="card-title">Aereo</h5>
				<p class="card-text">Dinanzi a me non fuor cose create se non etterne, e io etterno duro. Lasciate ogni speranza, voi ch'intrate</p>
			</div>
	</div>
 
	<div class="card" style="width: 18rem">
		<img class="card-img-top" src="bicicletta.jpg" alt="">
			<div class="card-body">
				<h5 class="card-title">Bici</h5>
				<p class="card-text">Dinanzi a me non fuor cose create se non etterne, e io etterno duro. Lasciate ogni speranza, voi ch'intrate</p>
			</div>
	</div>
	
	<div class="card" style="width: 18rem">
		<img class="card-img-top" src="minimoto.jpg" alt="">
			<div class="card-body">
				<h5 class="card-title">Moto</h5>
				<p class="card-text">Dinanzi a me non fuor cose create se non etterne, e io etterno duro. Lasciate ogni speranza, voi ch'intrate</p>
			</div>
	</div>
	
	<div class="card" style="width: 18rem">
		<img class="card-img-top" src="minimacchina.jpg" alt="">
			<div class="card-body">
				<h5 class="card-title">Macchina</h5>
				<p class="card-text">Dinanzi a me non fuor cose create se non etterne, e io etterno duro. Lasciate ogni speranza, voi ch'intrate</p>
			</div>
	</div>

	<div class="card" style="width: 18rem">
		<img class="card-img-top" src="mininave.jpg" alt="">
			<div class="card-body">
				<h5 class="card-title">Nave</h5>
				<p class="card-text">Dinanzi a me non fuor cose create se non etterne, e io etterno duro. Lasciate ogni speranza, voi ch'intrate</p>
			</div>
	</div>

	<div class="card" style="width: 18rem">
		<img class="card-img-top" src="minitreno.jpg" alt="">
			<div class="card-body">
				<h5 class="card-title">Treno</h5>
				<p class="card-text">Dinanzi a me non fuor cose create se non etterne, e io etterno duro. Lasciate ogni speranza, voi ch'intrate</p>
			</div>
	</div>
 </div>	
 <?php include('footer.html');?>