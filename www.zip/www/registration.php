<?php
// TODO: change credentials in the db/mysql_credentials.php file
require_once('db/mysql_credentials.php');

// Open DBMS Server connection


// Get values from $_POST, but do it IN A SECURE WAY
$email =$_POST['email']; // replace null with $_POST and sanitization
$first_name = $_POST['firstname']; // replace null with $_POST and sanitization
$last_name = $_POST['lastname']; // replace null with $_POST and sanitization
$password = $_POST['pass']; // replace null with $_POST and sanitization
$password_confirm = $_POST['confirm']; // replace null with $_POST and sanitization
$telephone =$_POST['telephone'];

// Get additional values from $_POST, but do it IN A SECURE WAY
// If you have additional values, change functions params accordingly
if(		!isset($_POST['email'])||empty($_POST['email'])||
		!isset($_POST['firstname'])||empty($_POST['firstname'])||
		!isset($_POST['lastname'])||empty($_POST['lastname'])||
		!isset($_POST['pass'])||empty($_POST['pass'])||
		!isset($_POST['confirm'])||empty($_POST['confirm'])||
		!isset($_POST['telephone'])){
			header('Location: inserimento.php?err=1');
			exit();
		}
function insert_user($email, $first_name, $last_name, $password, $password_confirm, $telephone, $db_connection) {

		$email=trim($email);
		$first_name=trim($first_name);
		$last_name=trim($last_name);
		$password=trim($password);
		$password_confirm=trim($password_confirm);
		$telephone=trim($telephone);

		if($password!=$password_confirm)
			return false;
		$password=sha1($password);
		
		$query="INSERT INTO cliente (idCliente, email, pword, nome, cognome, telefono)VALUES 
			(null,
			'".$email."',
			'".$password."',
			'".$first_name."',
			'".$last_name."',
			'".$telephone."')";

			$result=mysqli_query($db_connection,$query);
			
			if (mysqli_affected_rows($db_connection)==1) {				
				return true;
			} else {
				return false;
			}
		}
// Get user from login
$successful = insert_user($email, $first_name, $last_name, $password, $password_confirm, $telephone, $con);

if ($successful) {
    // Success message
    echo "$email registered successfully!";
} else {
    // Error message
	header('Location: inserimento.php?err=2');//non è stato possibile inserire, perché l'email è gia esistente,
}
