<?php

$mysql_host = "localhost";

// TODO: use your credentials here
$mysql_user = "root";
$mysql_pass = "FLV1920";
$mysql_db = "prova";
$con=mysqli_connect($mysql_host,$mysql_user,$mysql_pass,$mysql_db);
if(mysqli_connect_errno($con)){
	echo 'database error';
	exit();
}
