<html>
    <body>
        <?php echo $_GET["baseurl"]; ?>
</body>
</html>