<?php
    require_once('funzione.php');
    myHeader('REIMPOSTA PASSWORD', true);
    printMessage();
?>
    <h3 id = 'forgot_pwd'>Reimposta la password</h3>
    <h6 id = 'subtitle_forgotPwd'>Per reimpostarla occorre inserire la mail data al momento della registrazione</h6>
 
    <div id = 'forgotPwd'>
        <form action='forgotPwd.php' method='POST'>
            <br><input type='email' name='email' placeholder='email *' required><br>
        
            <br><input type='button' value='Invia' class='btn btn-primary'><br> 
        </form>
    </div>

    <br><h6 id = 'admin'> In caso di problemi contattare gli amministratori</h6><br>

    <div class='card-columns'>
        <div class='card' id = 'contatti'>
            <div class='card-body'>
                <img src='../images/Lorenzo.png' alt='Pagnoni Lorenzo' id = 'fotoAdminL'><br>
            <br> <h6>Lorenzo Pagnoni</h6>
                <h6 >Lorenzo@gmail.com</h6>
            </div>
        </div>
        
        <div class='card' id = 'contatti'>
            <div class='card-body'>
                <img src='../images/userF.jpeg' alt='Veronica Salvi' id = 'fotoAdminL'><br>
                <br> <h6>Salvi Veronica</h6>
                <h6 >Veronica@gmail.com</h6>
            </div>
        </div>
    </div>

    <div id = 'footer_forgot'>
        <?php
            include('../html/footer.html');
        ?>
    </div>