<?php
    require_once('funzione.php');
    checkSession(false);
    myHeader('MODIFICA PROFILO', true);
?>
	<h3 id='title_update'>Modifica del account VeichLe resize</h3>
  
<?php
    formUtente('update_profile.php');
?>

<br><a href='changePwdHTML.php' id = 'change_pwd'>Cambia Password</a>

<?php
    include('../html/footer.html');
?>