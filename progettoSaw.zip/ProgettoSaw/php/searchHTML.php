<?php
    require_once('funzione.php');
    myHeader('search', true);
    printMessage();
?>
    <form action='search.php' method='GET'>
      <!--  <label for='search' id = 'title_search'>Search</label>-->
        <h3 id='title_search'> Search a veichle <h3>
        <br><input type='text' name='search' id='input_search' placeholder='cerca per marca *' required><br>
        <input type='submit' value='Cerca' id ='button_search' class='btn btn-outline-secondary'>
    </form>
<?php

    include('../html/footer.html');
?>