<?php
    require_once('funzione.php');
    checkSession(true);
    myHeader('GESTIONE MODELLI', true);
    //true tutti apparte la login.php e la registration  
?>
    <!--a href='A_formVeichle.php'> Nuovo Modello </a>-->
    <h2 id='titolo_ordini'>Ordini</h2>  

<?php

    require_once('db/mysql_credentials.php');
    table_ordini($con);
?>
<input type='button' onclick="location.href='A_formVeichle.php'" value='Inserisci modello' class='btn btn-primary' id='model_but'>


<?php   
        mysqli_close($con);
        include('../html/footer.html');
?>
