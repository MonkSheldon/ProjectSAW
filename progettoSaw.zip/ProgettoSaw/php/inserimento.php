
<?php
	require_once('funzione.php');
	myHeader('REGISTRAZIONE', false);
?>

	<h3>Crea un account VeichLe resize</h3>


<?php
	formUtente('registration.php');
	include('../html/footer.html');
?>
