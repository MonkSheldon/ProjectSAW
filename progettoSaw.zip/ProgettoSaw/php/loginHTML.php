<?php
	require_once('funzione.php');
	myHeader('LOGIN', false);
	printMessage();

	if (isset($_COOKIE['id'])) {
		require_once('db/mysql_credentials.php');
		if ($stmt = mysqli_prepare($con,
						'SELECT idCliente, email, nome, cognome, telefono
							FROM cliente
							WHERE idCliente=? AND
								cookie>\''. time(). '\'')) {
			mysqli_stmt_bind_param($stmt, 'i', $_COOKIE['id']);
			$result = mysqli_stmt_execute($stmt);
			if ($result) {
				mysqli_stmt_store_result($stmt);
				$norows = mysqli_stmt_num_rows($stmt);
				if ($norows == 1) {
					mysqli_stmt_bind_result($stmt, $id, $em, $nome, $cognome, $tel);
					mysqli_stmt_fetch($stmt);
					mysqli_stmt_free_result($stmt);
					mysqli_stmt_close($stmt);
					sessionUtente($id, $em, $nome, $cognome, $tel);
					header('Location: index.php');
				}
			}
		}
		mysqli_close($con);
	}
?>
	<img src='../images/imm1.jpg' alt='auto' id = 'backgroundLogin'>	
	
	<div id = 'form_login'>

		<form action='login.php' method='POST'>
			<br><input type='email' name='email' placeholder='email' required><br>
			<br><input type='password' name='pass' placeholder='Password' required><br>
			<br><input type='submit' value='Accedi' class='btn btn-primary'><br>

			<!--<div class='field-group' id = 'check'>-->
				<div id = 'check'>
					<br><input type = 'checkbox' name='remember-me' value='remember-me' id = 'check'>
				</div>
				<br><label for='remember-me'>Remember me</label>
			<!--</div>-->
		</form>
		
		<br><a href='forgotPwdHTML.php'>Recupera la password</a><br>
	</div>
<?php
	include('../html/footer.html');
?>