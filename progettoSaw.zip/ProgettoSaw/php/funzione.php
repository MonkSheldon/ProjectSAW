<?php
	function checkSession($isAdmin) {
		session_start();

		if (!isset($_SESSION['id'])) {
			header('Location: login.php');
			exit();
		}
		if ($isAdmin && $_SESSION['admin'] == 0) {
			controlError('7');
			exit();
		}
	}

	function checkValuesUtente($form) {
        if (($form == 'inserimento' && (!isset($_POST['pass']) ||
			!isset($_POST['confirm']) || !isset($_POST['email']))) || //email only registration
            !isset($_POST['firstname']) || !isset($_POST['lastname'])) {
			myRedirect($form);
		}
		
        // Get values from $_POST, but do it IN A SECURE WAY
        if ($form == 'inserimento') {
            $password = trim($_POST['pass']); // replace null with $_POST and sanitization
	        $password_confirm = trim($_POST['confirm']); // replace null with $_POST and sanitization
			$email = trim($_POST['email']); // replace null with $_POST and sanitization
		}
       // $email = trim($_POST['email']); // replace null with $_POST and sanitization
        $first_name = trim($_POST['firstname']); // replace null with $_POST and sanitization
        $last_name = trim($_POST['lastname']); // replace null with $_POST and sanitization
		$phone = trim($_POST['phone']);
		
        // Get additional values from $_POST, but do it IN A SECURE WAY
        // If you have additional values, change functions params accordingly
        if (($form == 'inserimento' && (empty($password) ||
            empty($password_confirm) || empty($email))) || //email only registration
            empty($first_name) || empty($last_name)) {
			myRedirect($form);
		}
		
		$valuesUtente = array(
			//'email' => $email,
			'firstname' => $first_name,
			'lastname' => $last_name,
			'phone' => $phone);
        if ($form == 'inserimento') {
			$valuesUtente['email'] = $email;
			$valuesUtente['password'] = $password;
			$valuesUtente['password_confirm'] = $password_confirm;
		}
		
        return $valuesUtente;
	}

	function controllo_Password ($password){


	}

	function formUtente($action) {
		printMessage();
	?>
		<link rel='stylesheet' type='text/css' href='../css/form_inserimento.css'>
		<img src='../images/imm.jpg' alt='macchina' id='backgroundInsert'>	
			<div id='registrazione'>
				<form action='<?php echo $action; ?>' method='POST'>
					<!--<label for='firstname'>First name *</label>-->
					<br><input type='text' name='firstname' placeholder='Firstname *' <?php if (isset($_SESSION['firstname'])) {echo 'value=\''. $_SESSION['firstname']. '\'';} ?> required><br>
					
					<!--<label for='lastname'>Last name *</label>-->
					<br><input type='text' name='lastname' placeholder='Lastname *' <?php if (isset($_SESSION['lastname'])) {echo 'value=\''. $_SESSION['lastname']. '\'';} ?> required><br>

					<!--abel for='email'>E-mail *</label>-->
					<br><input type='email' name='email' placeholder='email@example.com *' <?php if (isset($_SESSION['email'])) {echo 'value=\''. $_SESSION['email']. '\'';} ?>  required><br>

					<?php
						if (!isset($_SESSION['id'])) { ?>
							<!--<label for='pass'>Password *</label>-->
							<br><input id='pass' type='password' name='pass' placeholder='Password *' required><br>

							<!--<label for='confirm'>Confirm Password *</label>-->
							<span id='message'></span>
							<br><input id='confirm' type='password' name='confirm' placeholder='Confirm *' required><br>
						
					<?php } ?>

					<!--<label for='telephone'>telefono *</label>-->
					<br><input type='text' name='phone' placeholder='Telephone' <?php if (isset($_SESSION['phone'])) {echo 'value=\''. $_SESSION['phone']. '\'';} ?> ><br>		
					<!-- controllo che le password corrispondano -->			
					<br><input type='submit'  value='<?php if(isset($_SESSION['id'])) {echo 'Modifica';} else {echo 'Registrati';} ?>' class='btn btn-success'>
				</form>	
			</div>

		
<?php
	}

	function generateRandomString($length) {
        $characters = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
        $randomString = '';
        for ($i = 0; $i < $length; $i++) {
            if ($length == 10) {
                if ($i == 0 || $i == 6)
                    $characters = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ';
                elseif ($i == 1 || $i == 8)
                    $characters = '0123456789';
            }
            $randomString .= $characters[rand(0, strlen($characters) - 1)];
        }
        return $randomString;
    }

	function myHeader($title, $op) {
?>
		<!DOCTYPE html>
		<html>
			<head>
				<link rel='stylesheet' type='text/css' href='../css/startSaw.css'>
				<link rel='stylesheet' type='text/css' href='../css/bootstrap.min.css'>
				<link rel='stylesheet' href='https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css'>
				<link rel='stylesheet' href='https://use.fontawesome.com/releases/v5.7.0/css/all.css' integrity='sha384-lZN37f5QGtY3VHgisS14W3ExzMWZxybE1SJSEsQp9S+oqd12jhcu+A56Ebc1zFSJ' crossorigin='anonymous'>
				<title><?php echo $title; ?></title>
				<script type='text/json' src='JS_function.json'></script>
			</head>
				<body>
					<nav class='navbar fixed'>
						<a class='navbar-brand' href='index.php'><img src='../images/logo1.PNG' alt='logo'></a>
							<div class='container'>
								<ul class='navbar-nav ml-auto'>
									<?php
										if ($op) { ?>
											<button class='navbar-toggler' type='button' data-toggle='collapse' data-target='#collapsibleNavbar'>
												<span><i class="fas fa-bars"></i></span>
											</button>

											<div class='collapse navbar-collapse' id='collapsibleNavbar'>
											<li class='nav-item'>
											
											<?php
												if (session_status() == PHP_SESSION_NONE)
													session_start();
												if (isset($_SESSION['id'])) { ?>
													<div class='dropdown'>
														<!--<button type='button' class='btn btn-primary dropdown-toggle' data-toggle='dropdown'>-->
															Ciao <?php echo $_SESSION['firstname']. ' '. $_SESSION['lastname']; ?>
														</button>

														<!--<div class='dropdown-menu'>-->
															<?php
																$dropdown = array(
																	'ordini.php?ammin=0' => 'I miei ordini',
																	'show_profile.php' => 'Modifica account',
																	'logout.php' => 'Logout');
																	
																	if ($_SESSION['admin'] == 1) {?>
																		<a class='dropdown-item' href='gestione_modelli.php'>Gestione modelli</a>
																		<a class='dropdown-item' href='ordini.php?ammin=1'>Gestione ordini</a>
																	<?php  
																		}
																	?>
																	
																	<?php foreach ($dropdown as $link => $name) { ?>
																	<a class='dropdown-item' href='<?php echo $link; ?>'><?php echo $name; ?></a>
															<?php
																} ?>
														<!--</div> -->
													</div>
											<?php
												}
												else { ?>
													<!--<i class='far fa-user'></i><i class='fas fa-shopping-cart'></i><i class='fas fa-sign-in-alt'></i><i class='fas fa-search'></i>-->
													<a class='nav-link' href='inserimento.php'> Registrati </a>
													<a class='nav-link' href='loginHTML.php'> Accedi </a>
									
											<?php
												} ?>
													<a class='nav-link' href='../php/searchHTML.php'>Cerca un prodotto </a>											
													<a class='nav-link' href='../php/carrello.php'> 
													<span><?php 
						
													if(!isset($_SESSION['count']))		
														echo '0';
													else
														echo $_SESSION['count'];
													?> Prodotti</a>
											</li>
									</div>
							</div>
									<?php
										} ?>
								</ul>
						</nav>
					<br>
<?php
	}

	function myRedirect($form) {
		if ($form == 'inserimento')
			header('Location: '. $form. '.php?err=1');
		else
			header('Location: '. $form. '.php?id='. $_SESSION['id'] .'&err=1');
		exit();
	}

	function printMessage() {
		if (isset($_GET['msg']) && $_GET['msg'] >= 1 && $_GET['msg'] <= 8) { ?>
			<div class='alert alert-success'>
			
			<?php
				switch ($_GET['msg']) {
					case 1:
						echo 'Modello inserito';
					break;
					case 2:
						echo 'Ordine cancellato con successo';
					break;
					case 3:
						echo 'La password è stata cambiata correttamente';
					break;
					case 4:
						echo 'Ordine completato';
					break;
					case 5:
						echo 'La password è stata inviata alla tua posta elettronica';
					break;
					case 6:
						echo 'Ordine cancellato con successo';
					break;
					case 7:
						echo '<strong>Registrazione andata a buon fine!</strong> Ora puoi accedere al tuo account effetuando il <a href=\'loginHTML.php\'>login</a>';
					break;
					case 8:
						echo '<strong>Modifica andata a buon fine!</strong>';
					break;

				}
			?>
			</div>
<?php
		}
		else if (isset($_GET['err']) && $_GET['err'] >= 1 && $_GET['err'] <= 12) { ?>
			<div class='alert alert-danger alert-dismissible fade show'>
			
			<?php
				switch ($_GET['err']) {
					case 1:
						echo 'I campi con * sono obbligatori';
					break;
					case 2:
						echo 'L\'utente è già inserito con questa mail';
					break;
					case 3:
						echo 'Username e/o password sbagliate';
					break;
					case 4:
						echo 'La password attuale non risulta corretta e/o la nuova password non è uguale a quella di conferma';
					break;
					case 5:
						echo 'L\'email inserita non risulta nel sistema';
					break;
					case 6:
						echo 'Momentaneamente abbiamo qualche problema con la reimpostazione della password. Riprova più tardi, ci dispiace per il disagio';
					break;
					case 7:
						echo 'Non hai i premessi per visualizzare questa pagina';
					break;
					case 8:
						echo 'Modello non trovato';
					break;
					case 9:
						echo 'Non è stato possibile inserire il modello nel sistema';
					break;
					case 10:
						echo 'Azione non valida per aggiornare il carrello';
					break;
					case 11:
						echo 'Il modello in analisi non risulta nel sistema';
					break;
					case 12:
						echo 'Ordine non confermato';
					break;
				} ?>
			</div>
	<?php
		}
	}

	function sessionUtente($id, $email, $admin, $first_name, $last_name, $phone) {
		session_start();
		$_SESSION['id'] = $id;
		$_SESSION['email'] = $email;
		$_SESSION['admin'] = $admin;
		$_SESSION['firstname'] = $first_name;
		$_SESSION['lastname'] = $last_name;
		$_SESSION['phone'] = $phone;
	}

	function table_ordini($db_connection)
	{
		$result = mysqli_query($db_connection, 'SELECT *
											FROM modello
											ORDER BY nome, marca ASC');

		if ($result && mysqli_affected_rows($db_connection) > 0) { //sono queste due echo da rivedere meglio per codice meno duplicato
		?> 
			<div id='tabella_ordini'>
				<table class='table'>
					<thead>
						<tr>
							<td>idModello</td>
							<td>Nome</td>
							<td>Marca</td>
							<td>Alimentazione</td>
							<td>tipo Modello</td>
							<td>Passeggeri</td>
							<td>Peso</td>
							<td>Potenza</td>
							<td>Prezzo</td>
							<td>Larghezza</td>
							<td>Lunghezza</td>
							<td>Altezza</td>
							<td>Colore</td>
						</tr>  
					</thead>  
					<?php
					while ($row = mysqli_fetch_assoc($result)) { 
					?>
					<tbody>
						<tr>
							<td><?php echo '<br>'. $row['idModello'];?></td>
							<td><?php echo '<br>'. $row['nome'];?></td>
							<td><?php echo '<br>'. $row['marca'];?></td>
							<td><?php echo '<br>'. $row['alimentazione'];?></td>
							<td><?php echo '<br>'. $row['tipoModello']; ?> </td>
							<td><?php echo '<br>'. $row['noPasseggeri'];?></td>
							<td><?php echo '<br>'. $row['peso'];?></td>
							<td><?php echo '<br>'. $row['potenza'];?></td>
							<td><?php echo '<br>'. $row['prezzo'];?></td>
							<td><?php echo '<br>'. $row['larghezza'];?></td>
							<td><?php echo '<br>'. $row['lunghezza'];?></td>
							<td><?php echo '<br>'. $row['altezza'];?></td>
							<td bgcolor='<?php echo $row['colore'];?>'> </td>
						</tr>
					</tbody>

					<?php
					}
		}
					else
						echo 'Nessun modello inserito nel sistema'; 
					?>
				</table>
			</div>
<?php
	}
?>