<?php
  require_once('funzione.php');
  myHeader('PRODOTTI', true);
  require_once('db/mysql_credentials.php');

  $veichle = $_GET['veichle'];

  if ($stmt = mysqli_prepare($con,
						'SELECT idModello, nome, marca
              FROM modello
              WHERE tipoModello=?')) {
    mysqli_stmt_bind_param($stmt,'s', $veichle);
    $result = mysqli_stmt_execute($stmt);
    if ($result) {
      mysqli_stmt_store_result($stmt);
      $norows = mysqli_stmt_num_rows($stmt);
      mysqli_stmt_bind_result($stmt, $idModel, $name, $brand);
      if ($norows >= 1) {?>
        <h2 id='title_products'>I nostri veicoli</h2>
        <link rel='stylesheet' type='text/css' href='../css/pagina.css'>
        <div class='card-columns'>
        <?php 
          for ($i = 0; $i < $norows; $i++) { 
            mysqli_stmt_fetch($stmt); ?> 
            <div class='card' style='width: 18rem;'>
              <div class='card-body'>
                <p class='card-text'><?php echo 'Nome: '. $name. '<br>Marca: '. $brand; ?></p>
                <a href='update_products.php?action=aggiungi&idModel=<?php echo $idModel;?>' class='btn btn-primary'>Aggiungi al carrello</a>
              </div>
            </div>
    <?php } ?>
        </div>
<?php
        mysqli_stmt_free_result($stmt);
        mysqli_stmt_close($stmt);
			}
		}
  }
  mysqli_close($con);
  
	include('../html/footer.html');
?>