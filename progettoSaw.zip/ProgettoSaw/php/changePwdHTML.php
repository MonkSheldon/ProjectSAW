<?php
    require_once('funzione.php');
    checkSession(false);
    myHeader('CAMBIA PASSWORD', true);
    printMessage();
?>
	
    <form action='changePwd.php' method='POST'>
        <!--<label for='pass'>Password *</label>-->
		<br><input type='password' name='pass' id='form_change_pwd' placeholder='password *' required><br>

        <!--<label for='newpass'>New Password *</label>-->
		<br><input type='password' name='newpass' id='form_change_pwd' placeholder='new password *' required><br>

        <!--<label for='confirm'>Confirm Password *</label>-->
        <br><input type='password' name='confirm' id='form_change_pwd' placeholder='confirm *' required><br>
    
        <br><input type='button' value='Cambia password' id='changepwd_but' class='btn btn-info'>
    </form>
    
<?php
    include('../html/footer.html');
?>