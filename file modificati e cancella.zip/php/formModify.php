<?php
	require_once("funzione.php");
	myHeader("REGISTRAZIONE", false);
?>





<?php
	include("../html/footer.html");
?>