<?php
require_once('funzione.php');
CheckSession();
//qua devi mettere gli articoli in vendita


?>