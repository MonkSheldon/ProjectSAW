<?php
	$mysql_host = "localhost";
	$mysql_user = "root";
	$mysql_pass = "";//"FLV1920";
	$mysql_db = "prova";//"prova";
	$con = mysqli_connect($mysql_host, $mysql_user, $mysql_pass, $mysql_db);
	if (mysqli_connect_errno($con)) {
		echo "Database error";
		exit();
	}
?>