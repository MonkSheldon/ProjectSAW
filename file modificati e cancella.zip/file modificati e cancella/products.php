<?php
	require_once("funzione.php");
	myHeader("prodotti", true);
?>
<!-- questa pagina avrà una select dove prende dal dbms i veicoli da far vedere, in base alla card cliccata sull'index -->
<h2> I nostri veicoli </h2>
<link rel="stylesheet" type="text/css" href="../css/pagina.css">
<div class="card-columns">
<?php for ($i = 0; $i < 3; $i++) { ?> <!-- i< delle righe che trova la select -->

<div class="card" style="width: 18rem;">
  <div class="card-body">
    <p class="card-text">Vuolsi così colà dove si puote ciò che si vuole, e più non dimandare</p>
    <a href="" class="btn btn-primary">Aggiungi al carrello</a>
  </div>
</div> <?php } ?>
</div>

<?php include('../html/footer.html');?>