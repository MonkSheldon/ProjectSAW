<?php
require_once("funzione.php");
//checkSession();
require_once('db/mysql_credentials.php');
if (!isset($_POST['email']) || !isset($_POST['pass']))
{ 
    header('Location: index.php?err=1');
    exit();
}
$email = trim($_POST['email']); 
$pass = trim($_POST['pass']);
$pass = sha1($pass);
$exist=search($email,$con); 

if($exist){
    $delete = mysqli_query($con,"
        DELETE FROM cliente WHERE email='".$email."' AND pword='".$pass."'");
    if($delete)
    {
        header ('Location: logout.php?msg=1');
    } 
}else{
    header('Location: formCancellazione.php?err=4');   
}

?>
