<?php
    if (isset($_COOKIE['id']))
        setcookie("id", "", time() - 3600);
    session_start();
    session_unset();
    session_destroy();
if(count($_GET)>0)  
{
    if(isset($_GET['msg']) && $_GET['msg'] == "1")
        header('Location: index.php?msg=1');
    else
        header('Location: index.php?');
}
?>  