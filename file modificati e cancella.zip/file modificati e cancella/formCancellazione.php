<?php
require_once("funzione.php");
myHeader("CANCELLAZIONE",false);

if (count($_GET) > 0) {
	controlError($_GET['err']);
}

?>
<html>

<form action="cancellazione.php" method="POST">
    <br><input type="email" name="email" placeholder="email *" required><br>
	<br><input type="password" name="pass" placeholder="password *" required><br>
<br><input type="submit" value="Submit">
</form>
</html>
<?php
	include("../html/footer.html");
?>